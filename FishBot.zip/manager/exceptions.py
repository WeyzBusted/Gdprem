class ValidationError(Exception):
    pass
