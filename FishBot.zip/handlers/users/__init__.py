from .get_session import dp
from .start_bot import dp

__all__ = ['dp']
