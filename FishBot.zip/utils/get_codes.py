import re
from pydantic import BaseModel
from pyrogram import Client

from data import API_ID, API_HASH


class Codes(BaseModel):
    code: str
    date: str


async def get_codes_list(session: str):
    app = Client(session, API_ID, API_HASH)
    await app.connect()
    try:
        codes = list()
        async for message in app.get_chat_history(777000):
            if 'Код подтверждения' in message.text or 'Login code' in message.text:
                try:
                    codes.append(
                        Codes(
                            code=re.findall('[0-9]+', message.text)[0],
                            date=message.date.strftime('%d.%m.%Y в %H:%M:%S')
                        )
                    )
                except IndexError:
                    pass
        await app.disconnect()
        return codes
    except Exception:
        return False
